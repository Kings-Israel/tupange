<h4 class="order-{{ $order->status }}">
   {{ $order->status }}
</h4>
