<li>
   <a title="Cart" href="{{ route('client.cart') }}"><i class="fa fa-shopping-cart" style="font-size: 12px; cursor: pointer"></i> ({{ $itemsCount }})</a>
</li>
