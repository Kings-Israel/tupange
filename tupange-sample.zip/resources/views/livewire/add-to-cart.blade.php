<li>
   <a title="Cart" href="" wire:click.prevent="addServiceToCart({{ $service }})"><i class="fa fa-shopping-cart" style="font-size: 14px; cursor: pointer"></i></a>
</li>
