<?php
echo phpinfo()
?>
