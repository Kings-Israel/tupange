<div id="image-viewer">
   <span class="close">&times;</span>
   <img class="modal-content" id="full-image">
 </div>
