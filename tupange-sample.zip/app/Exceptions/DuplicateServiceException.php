<?php

namespace App\Exceptions;

use Exception;

class DuplicateServiceException extends Exception
{
    //
}
