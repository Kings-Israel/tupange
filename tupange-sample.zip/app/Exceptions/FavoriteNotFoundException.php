<?php

namespace App\Exceptions;

use Exception;

class FavoriteNotFoundException extends Exception
{
    //
}
