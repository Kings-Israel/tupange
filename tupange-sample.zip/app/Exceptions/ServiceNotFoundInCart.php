<?php

namespace App\Exceptions;

use Exception;

class ServiceNotFoundInCart extends Exception
{
    //
}
