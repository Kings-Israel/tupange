<?php

namespace App\Exceptions;

use Exception;

class MailNotSent extends Exception
{
    //
}
