<?php

namespace App\Exceptions;

use Exception;

class DuplicateFavoriteException extends Exception
{
    //
}
