<?php

namespace App\Notifications;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class ClientNotification extends Notification
{
   use Queueable;

   public $order;
   public $type;

   /**
    * Create a new notification instance.
    *
    * @return void
    */
   public function __construct(Order $order, string $type)
   {
      $this->order = $order;
      $this->type = $type;
   }

   /**
    * Get the notification's delivery channels.
    *
    * @param  mixed  $notifiable
    * @return array
    */
   public function via($notifiable)
   {
      return ['database'];
   }

   /**
    * Get the mail representation of the notification.
    *
    * @param  mixed  $notifiable
    * @return \Illuminate\Notifications\Messages\MailMessage
    */
   public function toMail($notifiable)
   {
      return (new MailMessage)
                  ->line('The introduction to the notification.')
                  ->action('Notification Action', url('/'))
                  ->line('Thank you for using our application!');
   }

   /**
    * Get the array representation of the notification.
    *
    * @param  mixed  $notifiable
    * @return array
    */
   public function toArray($notifiable)
   {
      return [
         'order_id' => $this->order->id,
         'order' => $this->order->order_id,
         'service_id' => $this->order->service->id,
         'service' => $this->order->service->service_title,
         'type' => $this->type,
         'vendor' => $this->order->service->vendor->company_name
      ];
   }
}
